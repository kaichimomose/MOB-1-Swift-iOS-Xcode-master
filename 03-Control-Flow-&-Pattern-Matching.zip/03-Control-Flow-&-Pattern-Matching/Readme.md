# Control Flow & Pattern Matching

## Objectives

- Learn about logic statements in Swift
- Practice pattern matching in enums
- Model state with enums

## Class Materials

Go through:

[Swift Playgrounds - Conditionals](conditionals.playground)


## Challenges

1. Finish the challenges in the Swift playgrounds