# Variables, Functions & Operators

## Objectives

- Familiarize yourself with Xcode, Swift and Playgrounds
- Develop an intuition on when to use classes, structs, enums and protocols
- Learn how to write functions, control statements

## Vocabulary

- Comments
- Variable
- Playgrounds
- (Im)mutable

## Class Materials

Download and go through:

- [Swift Playgrounds - Variables](Variables.playground)
